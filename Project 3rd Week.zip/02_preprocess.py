"""
02_preprocess.py
-----------------
Cleans the raw historical dataset:
 - parses dates, sorts chronologically
 - removes duplicate rows
 - fixes/flags outliers
 - fills missing values (time-aware interpolation)
 - engineers features used by the models (lags, rolling stats, calendar parts)
"""

import numpy as np
import pandas as pd

df = pd.read_csv("historical_sales_raw.csv")

# 1) Parse dates robustly and sort
df["date"] = pd.to_datetime(df["date"], format="mixed")
df = df.sort_values("date")

# 2) Drop exact duplicate rows
before = len(df)
df = df.drop_duplicates(subset=["date"])
print(f"Removed {before - len(df)} duplicate rows.")

# 3) Re-index to a complete monthly calendar so no gaps in time exist
df = df.set_index("date").asfreq("MS")

# 4) Outlier handling: flag values > 4 std devs from the rolling median as bad data,
#    then treat them like missing values (so they get interpolated, not left in).
rolling_median = df["sales"].rolling(6, center=True, min_periods=1).median()
resid = (df["sales"] - rolling_median).abs()
outlier_mask = resid > (4 * resid.std())
print(f"Flagged {outlier_mask.sum()} outlier value(s) for correction.")
df.loc[outlier_mask, "sales"] = np.nan

# 5) Fill missing values (original NaNs + corrected outliers) via time interpolation
missing_before = df["sales"].isna().sum()
df["sales"] = df["sales"].interpolate(method="time").bfill().ffill()
print(f"Interpolated {missing_before} missing/corrected value(s).")

# 6) Feature engineering
df["month"] = df.index.month
df["year"] = df.index.year
df["time_index"] = np.arange(len(df))          # linear trend feature
df["month_sin"] = np.sin(2 * np.pi * df["month"] / 12)   # cyclical encoding
df["month_cos"] = np.cos(2 * np.pi * df["month"] / 12)

for lag in [1, 2, 3, 12]:
    df[f"lag_{lag}"] = df["sales"].shift(lag)

df["rolling_mean_3"] = df["sales"].shift(1).rolling(3).mean()

df_clean = df.dropna().reset_index()  # drop early rows that lack lag history
df_clean.to_csv("historical_sales_clean.csv", index=False)

print(f"\nFinal clean dataset: {len(df_clean)} rows, {df_clean.shape[1]} columns")
print(df_clean.head())
