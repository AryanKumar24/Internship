# Predictive Analytics Using Historical Data
**Internship Project**

Forecasts future trends from historical time-series data using regression and
time-series techniques, with full data cleaning, model evaluation, and
visualization.

## What this project does

| Stage | Script | Details |
|---|---|---|
| 1. Data | `01_generate_data.py` | Sample historical sales dataset (72 months), with realistic messiness: missing values, duplicate rows, one outlier, inconsistent date formats. Swap in your own CSV here if you have one (needs a date column + a numeric value column). |
| 2. Cleaning | `02_preprocess.py` | Parses/sorts dates, removes duplicates, detects and corrects outliers, fills gaps with time-aware interpolation, engineers features (trend index, cyclical month encoding, lag features, rolling averages). |
| 3. Modeling | `03_model_and_forecast.py` | Trains **Linear Regression** and **Random Forest Regression**, plus a classic **Exponential Smoothing** time-series benchmark. Evaluates all three on a held-out 12-month test period, then retrains the model on all data to forecast the next 12 months. |

## How to run

```bash
pip install pandas numpy scikit-learn matplotlib
python 01_generate_data.py
python 02_preprocess.py
python 03_model_and_forecast.py
```

Each script writes its output to a CSV so you can inspect every stage:
`historical_sales_raw.csv` → `historical_sales_clean.csv` → `model_evaluation_results.csv` + `future_forecast.csv`.

## Evaluation metrics used

- **MAE** (Mean Absolute Error) — average size of the error, in the same units as the data
- **RMSE** (Root Mean Squared Error) — like MAE but penalizes large errors more
- **R²** — how much of the variance in the actual values the model explains
- **MAPE** — average error as a percentage, useful for comparing across different scales

## Results on this sample dataset

```
     Linear Regression | MAE:  34.86 | RMSE: 45.64 | R2:  0.576 | MAPE: 3.31%
         Random Forest | MAE:  71.50 | RMSE: 89.00 | R2: -0.610 | MAPE: 6.59%
Exp. Smoothing (a=0.4) | MAE:  83.09 | RMSE: 88.66 | R2: -0.598 | MAPE: 8.00%
```

**Linear Regression won here** — a useful, real lesson: with only 5 years of
monthly data and a clear trend + seasonal pattern, a simple model with good
features generalizes better than a more flexible model like Random Forest,
which has more room to overfit on a small dataset. This is a good talking
point for a project writeup/viva: *more complex ≠ more accurate*, especially
on small time series.

## Charts produced

- `forecast_results.png` — actual vs. predicted for all 3 models on the test period, plus the full history + 12-month forecast
- `model_comparison.png` — bar chart comparing RMSE across models

## Using your own data

Replace Step 1 with your real CSV (just needs `date` and a numeric target
column — rename your target column to `sales` or edit `TARGET` in
`03_model_and_forecast.py`), then run steps 2 and 3 as-is.

## What this demonstrates (for your report)

- Data cleaning & preprocessing: handling missing values, duplicates, outliers, inconsistent formats
- Feature engineering for time series: lag features, rolling statistics, cyclical encoding of seasonality
- Regression modeling (Linear Regression, Random Forest) vs. classical time-series (Exponential Smoothing)
- Proper time-series evaluation (chronological train/test split — never shuffle time-ordered data)
- Multi-step future forecasting with a walk-forward approach
- Model comparison and selection based on quantitative metrics
