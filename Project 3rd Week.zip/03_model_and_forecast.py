"""
03_model_and_forecast.py
-------------------------
Trains multiple predictive models on the cleaned historical data,
evaluates their accuracy on a held-out test period, and forecasts
future values. Produces comparison charts.

Models used:
 1) Linear Regression        -> classic regression baseline on trend+seasonality features
 2) Random Forest Regressor  -> non-linear regression using lag/rolling features
 3) Simple Exponential Smoothing (hand-rolled) -> classic time-series benchmark
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

df = pd.read_csv("historical_sales_clean.csv", parse_dates=["date"])
df = df.set_index("date")

FEATURES = ["time_index", "month_sin", "month_cos", "lag_1", "lag_2", "lag_3", "lag_12", "rolling_mean_3"]
TARGET = "sales"

# ---- Chronological train/test split (never shuffle time series!) ----
test_size = 12  # hold out the most recent 12 months to test accuracy
train = df.iloc[:-test_size]
test = df.iloc[-test_size:]

X_train, y_train = train[FEATURES], train[TARGET]
X_test, y_test = test[FEATURES], test[TARGET]


def evaluate(y_true, y_pred, name):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    print(f"{name:>22} | MAE: {mae:7.2f} | RMSE: {rmse:7.2f} | R2: {r2:6.3f} | MAPE: {mape:5.2f}%")
    return {"model": name, "MAE": mae, "RMSE": rmse, "R2": r2, "MAPE": mape}


results = []

# ---- Model 1: Linear Regression ----
lr = LinearRegression()
lr.fit(X_train, y_train)
pred_lr = lr.predict(X_test)
results.append(evaluate(y_test, pred_lr, "Linear Regression"))

# ---- Model 2: Random Forest Regressor ----
rf = RandomForestRegressor(n_estimators=300, max_depth=6, random_state=42)
rf.fit(X_train, y_train)
pred_rf = rf.predict(X_test)
results.append(evaluate(y_test, pred_rf, "Random Forest"))

# ---- Model 3: Simple Exponential Smoothing (classic time-series benchmark) ----
def simple_exp_smoothing(series, alpha=0.4):
    smoothed = [series.iloc[0]]
    for val in series.iloc[1:]:
        smoothed.append(alpha * val + (1 - alpha) * smoothed[-1])
    return np.array(smoothed)

# Fit on train only, then walk forward one step at a time through the test period
history = list(train[TARGET])
ses_preds = []
alpha = 0.4
level = history[0]
for val in history[1:]:
    level = alpha * val + (1 - alpha) * level
for actual in test[TARGET]:
    ses_preds.append(level)
    level = alpha * actual + (1 - alpha) * level
ses_preds = np.array(ses_preds)
results.append(evaluate(y_test, ses_preds, "Exp. Smoothing (a=0.4)"))

results_df = pd.DataFrame(results).sort_values("RMSE")
results_df.to_csv("model_evaluation_results.csv", index=False)
best_model_name = results_df.iloc[0]["model"]
print(f"\nBest model on held-out test period: {best_model_name}")

# =========================================================
# Forecast the next 12 months into the future using the RF model
# (retrain on ALL available data for the final production forecast)
# =========================================================
FORECAST_HORIZON = 12
full_df = df.copy()

rf_final = RandomForestRegressor(n_estimators=300, max_depth=6, random_state=42)
rf_final.fit(full_df[FEATURES], full_df[TARGET])

future_rows = []
history_series = full_df[TARGET].copy()
last_time_index = full_df["time_index"].iloc[-1]
last_date = full_df.index[-1]

for step in range(1, FORECAST_HORIZON + 1):
    future_date = last_date + pd.DateOffset(months=step)
    month = future_date.month
    row = {
        "time_index": last_time_index + step,
        "month_sin": np.sin(2 * np.pi * month / 12),
        "month_cos": np.cos(2 * np.pi * month / 12),
        "lag_1": history_series.iloc[-1],
        "lag_2": history_series.iloc[-2],
        "lag_3": history_series.iloc[-3],
        "lag_12": history_series.iloc[-12],
        "rolling_mean_3": history_series.iloc[-3:].mean(),
    }
    X_future = pd.DataFrame([row])[FEATURES]
    pred = rf_final.predict(X_future)[0]
    future_rows.append({"date": future_date, "forecast_sales": pred})
    history_series.loc[future_date] = pred  # feed prediction back in for next step's lags

forecast_df = pd.DataFrame(future_rows).set_index("date")
forecast_df.to_csv("future_forecast.csv")
print("\nNext 12 months forecast:")
print(forecast_df.round(2))

# =========================================================
# Visualization
# =========================================================
fig, axes = plt.subplots(2, 1, figsize=(12, 10))

# Plot 1: Actual vs Predicted on test period, for all 3 models
ax = axes[0]
ax.plot(train.index[-18:], train[TARGET].iloc[-18:], label="Historical (train)", color="gray")
ax.plot(test.index, y_test, label="Actual", color="black", marker="o", linewidth=2)
ax.plot(test.index, pred_lr, label="Linear Regression", linestyle="--", marker="x")
ax.plot(test.index, pred_rf, label="Random Forest", linestyle="--", marker="s")
ax.plot(test.index, ses_preds, label="Exp. Smoothing", linestyle="--", marker="^")
ax.set_title("Model Accuracy: Actual vs Predicted (held-out test months)")
ax.set_ylabel("Sales")
ax.legend()
ax.grid(alpha=0.3)

# Plot 2: Full history + future forecast
ax = axes[1]
ax.plot(full_df.index, full_df[TARGET], label="Historical Sales", color="steelblue")
ax.plot(forecast_df.index, forecast_df["forecast_sales"], label="Forecast (next 12 months)",
        color="darkorange", marker="o")
ax.axvline(full_df.index[-1], color="gray", linestyle=":", label="Forecast start")
ax.set_title("Historical Trend + Future Forecast (Random Forest, retrained on full data)")
ax.set_ylabel("Sales")
ax.legend()
ax.grid(alpha=0.3)

plt.tight_layout()
plt.savefig("forecast_results.png", dpi=150)
print("\nSaved chart -> forecast_results.png")

# Plot 3: Model comparison bar chart
fig2, ax2 = plt.subplots(figsize=(8, 5))
ax2.bar(results_df["model"], results_df["RMSE"], color=["#4C72B0", "#DD8452", "#55A868"])
ax2.set_ylabel("RMSE (lower is better)")
ax2.set_title("Model Comparison: Test-Set RMSE")
for i, v in enumerate(results_df["RMSE"]):
    ax2.text(i, v + 1, f"{v:.1f}", ha="center")
plt.tight_layout()
plt.savefig("model_comparison.png", dpi=150)
print("Saved chart -> model_comparison.png")
