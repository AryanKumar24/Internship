"""
01_generate_data.py
--------------------
Generates a realistic synthetic 'historical sales' dataset so the rest of the
pipeline (cleaning -> modeling -> evaluation -> visualization) has something
to work on. If you have a real dataset, skip this script and just point
02_preprocess.py at your own CSV (needs a date column + a numeric value column).
"""

import numpy as np
import pandas as pd

np.random.seed(42)

# 6 years of monthly data
n_months = 72
dates = pd.date_range(start="2020-01-01", periods=n_months, freq="MS")

t = np.arange(n_months)

# Components of the series:
trend = 500 + 8 * t                                   # steady upward business growth
seasonality = 120 * np.sin(2 * np.pi * t / 12)         # yearly seasonal cycle
noise = np.random.normal(0, 35, n_months)              # random market noise
promo_boost = np.where((t % 12) == 10, 150, 0)         # Nov promo spike each year

sales = trend + seasonality + noise + promo_boost
sales = np.round(sales, 2)

df = pd.DataFrame({"date": dates, "sales": sales})

# --- Inject realistic "dirty data" problems on purpose, to be cleaned later ---
# 1) A few missing values
missing_idx = np.random.choice(df.index[5:], size=4, replace=False)
df.loc[missing_idx, "sales"] = np.nan

# 2) A couple of duplicate rows
df = pd.concat([df, df.iloc[[10, 30]]], ignore_index=True)

# 3) A wildly wrong outlier (data entry error)
df.loc[df["date"] == "2022-06-01", "sales"] = 9999

# 4) Inconsistent date formatting for a couple of rows (as strings)
df["date"] = df["date"].astype(str)
df.loc[2, "date"] = "2020-03-01 00:00:00"

df.to_csv("historical_sales_raw.csv", index=False)
print(f"Generated historical_sales_raw.csv with {len(df)} rows (includes intentional dirty data).")
print(df.head(8))
